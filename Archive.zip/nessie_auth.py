# Secret python file with authentication information

apiKey = '327438489a9ee9579fd4ad163fb7233b'
customerId = '58d64eab1756fc834d9064f1'

def getApiKey():
	return apiKey
	
def getCustomerId():
	return customerId